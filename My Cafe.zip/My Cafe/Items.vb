﻿Imports System.Data.SqlClient

Public Class Items
    Dim con = New SqlConnection("Data Source=DESKTOP-FPLPJ7E\SQLEXPRESS01;Initial Catalog=cafe;Integrated Security=True")
    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles CatTb.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If CatTb.Text = "" Then
            MsgBox("Enter the Category")
        Else
            con.open()
            Dim query = "insert into Categorytb1 values('" & CatTb.Text & "')"
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            MsgBox("Category Added")
            con.close()
            CatTb.Text = ""
            Fillcategory()
        End If


    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        Dim obj = New Login
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Application.Exit()
    End Sub
    Dim key = 0
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)
        Dim row As DataGridViewRow = GunaDataGridView1.Rows(e.RowIndex)
        ItName.Text = row.Cells(1).Value.ToString
        ComboBox1.SelectedValue = row.Cells(2).Value.ToString
        ItPrice.Text = row.Cells(3).Value.ToString
        ItQty.Text = row.Cells(4).Value.ToString
        If ItName.Text = "" Then
            key = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If
    End Sub

    Private Sub ItName_TextChanged(sender As Object, e As EventArgs) Handles ItName.TextChanged

    End Sub
    Private Sub Reset()
        ItName.Text = ""
        ComboBox1.SelectedIndex = 0
        ItQty.Text = ""
        ItPrice.Text = ""

    End Sub

    Private Sub Fillcategory()
        con.open()
        Dim cmd = New SqlCommand("select * from Categorytb1", con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim Tb1 = New DataTable()
        adapter.Fill(Tb1)
        ComboBox1.DataSource = Tb1
        ComboBox1.DisplayMember = "CatName"
        ComboBox1.ValueMember = "CatName"


        con.close()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Reset()
    End Sub
    Private Sub DisplayItem()
        con.open()
        Dim query = "select * from Itemtb1"
        Dim cmd = New SqlCommand(query, con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        builder = New SqlCommandBuilder(adapter)
        Dim ds = New DataSet()
        adapter.Fill(ds)
        GunaDataGridView1.DataSource = ds.Tables(0)


        con.close()
    End Sub

    Private Sub Items_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Fillcategory()
        DisplayItem()
    End Sub

    Private Sub ItCat_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If ComboBox1.SelectedIndex = -1 Or ItName.Text = "" Or ItPrice.Text = "" Or ItQty.Text = "" Then
            MsgBox("Missing Information")
        Else
            con.open()
            Dim query = "insert into Itemtb1 values('" & ItName.Text & "','" & ComboBox1.SelectedValue.ToString() & "','" & ItPrice.Text & "','" & ItQty.Text & "')"
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            MsgBox("Item Added")
            con.close()
            Reset()
            DisplayItem()
        End If
    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click
        Orders.Show()
        Me.Hide()
    End Sub

    Private Sub ItPrice_TextChanged(sender As Object, e As EventArgs) Handles ItPrice.TextChanged

    End Sub

    Private Sub ItQty_TextChanged(sender As Object, e As EventArgs) Handles ItQty.TextChanged

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If ComboBox1.SelectedIndex = -1 Or ItName.Text = "" Or ItPrice.Text = "" Or ItQty.Text = "" Then
            MsgBox("Missing Information")
        Else
            con.open()
            Dim query = "update Itemtb1 set ItName='" & ItName.Text & "',ItCat='" & ComboBox1.SelectedValue.ToString() & "',ItPrice='" & ItPrice.Text & "',ItQty='" & ItQty.Text & "' where ItId=" & key & ""
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            MsgBox("Item Updated")
            con.close()
            Reset()
            DisplayItem()
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If key = 0 Then
            MsgBox("Select Details to delete")
        Else
            con.open()
            Dim query = "delete from Itemtb1 where ItId=" & key & ""
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            MsgBox("Item Deleted")
            con.close()
            Reset()
            DisplayItem()
        End If
    End Sub

    Private Sub GunaDataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles GunaDataGridView1.CellContentClick

    End Sub
End Class