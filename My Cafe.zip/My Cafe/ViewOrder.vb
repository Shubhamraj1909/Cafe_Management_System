﻿Imports System.Data.SqlClient

Public Class ViewOrder
    Dim con = New SqlConnection("Data Source=DESKTOP-FPLPJ7E\SQLEXPRESS01;Initial Catalog=cafe;Integrated Security=True")
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Orders.Show()
        Me.Hide()
    End Sub
    Private Sub DisplayBills()
        con.open()
        Dim query = "select * from Ordertb1"
        Dim cmd = New SqlCommand(query, con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        builder = New SqlCommandBuilder(adapter)
        Dim ds = New DataSet()
        adapter.Fill(ds)
        GunaDataGridView1.DataSource = ds.Tables(0)
        con.close()

    End Sub
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub ViewOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DisplayBills()
    End Sub
End Class