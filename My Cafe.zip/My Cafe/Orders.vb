﻿Imports System.Data.SqlClient
Public Class Orders

    Dim con = New SqlConnection("Data Source=DESKTOP-FPLPJ7E\SQLEXPRESS01;Initial Catalog=cafe;Integrated Security=True")

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub


    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
    Private Sub Fillcategory()
        con.open()
        Dim cmd = New SqlCommand("select * from Categorytb1", con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim Tb1 = New DataTable()
        adapter.Fill(Tb1)
        CbItemCategory.DataSource = Tb1
        CbItemCategory.DisplayMember = "CatName"
        CbItemCategory.ValueMember = "CatName"
        con.close()
    End Sub

    Private Sub FilterByCategory()
        con.open()
        Dim query = "select * from Itemtb1 where ItCat='" & CbItemCategory.SelectedValue.ToString() & "'"
        Dim cmd = New SqlCommand(query, con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        builder = New SqlCommandBuilder(adapter)
        Dim ds = New DataSet()
        adapter.Fill(ds)
        ItemDGV.DataSource = ds.Tables(0)
        con.close()
    End Sub
    Private Sub DisplayItem()
        con.open()
        Dim query = "select * from Itemtb1"
        Dim cmd = New SqlCommand(query, con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        builder = New SqlCommandBuilder(adapter)
        Dim ds = New DataSet()
        adapter.Fill(ds)
        ItemDGV.DataSource = ds.Tables(0)
        con.close()

    End Sub
    Dim prodName As String
    Dim i = 0, GrandTotal = 0, Price, Qnty


    Private Sub Orders_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Fillcategory()
        DisplayItem()
    End Sub

    Private Sub GunaDataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles ItemDGV.CellContentClick
        'Dim row As DataGridViewRow = ItemDGV.Rows(e.RowIndex)
        'prodName = row.Cells(1).Value.ToString

        'If prodName = "" Then
        '    key = 0
        '    Stock = 0
        'Else
        '    key = Convert.ToInt32(row.Cells(0).Value.ToString)
        '    Stock = Convert.ToInt32(row.Cells(4).Value.ToString)
        '    Price = Convert.ToInt32(row.Cells(3).Value.ToString)
        'End If
        ''Dim row As DataGridViewRow = GunaDataGridView1.Rows(e.RowIndex)
        ''ItName.Text = row.Cells(1).Value.ToString
        'ComboBox1.SelectedValue = row.Cells(2).Value.ToString
        'ItPrice.Text = row.Cells(3).Value.ToString
        'ItQty.Text = row.Cells(4).Value.ToString
        'If ItName.Text = "" Then
        '    key = 0
        'Else
        '    key = Convert.ToInt32(row.Cells(0).Value.ToString)
        'End If
    End Sub

    Private Sub GunaDataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles BillDGV.CellContentClick
        'Dim row As DataGridViewRow = GunaDataGridView2.Rows(e.RowIndex)
        'prodName = row.Cells(1).Value.ToString

        'If prodName = "" Then
        '    key = 0
        '    Stock = 0
        'Else
        '    key = Convert.ToInt32(row.Cells(0).Value.ToString)
        '    Stock = Convert.ToInt32(row.Cells(4).Value.ToString)
        '    Price = Convert.ToInt32(row.Cells(3).Value.ToString)
        'End If
        'ComboBox1.SelectedValue = row.Cells(2).Value.ToString
        'ItPrice.Text = row.Cells(3).Value.ToString
        'ItQty.Text = row.Cells(4).Value.ToString
        'If ItName.Text = "" Then
        '    key = 0
        'Else
        '    key = Convert.ToInt32(row.Cells(0).Value.ToString)
        'End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)
        AddBill()

    End Sub


    Private Sub Button5_Click(sender As Object, e As EventArgs)
        ViewOrder.Show()
        Me.Hide()
    End Sub

    Private Sub GunaDataGridView2_MouseClick(sender As Object, e As MouseEventArgs) Handles BillDGV.MouseClick
        'Dim row As DataGridViewRow = GunaDataGridView2.Rows(e.RowIndex)
        'prodName = row.Cells(1).Value.ToString

        'If prodName = "" Then
        '    key = 0
        '    Stock = 0
        'Else
        '    key = Convert.ToInt32(row.Cells(0).Value.ToString)
        '    Stock = Convert.ToInt32(row.Cells(4).Value.ToString)
        '    Price = Convert.ToInt32(row.Cells(3).Value.ToString)
        'End If
    End Sub

    Private Sub GunaDataGridView2_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles BillDGV.CellMouseClick
        'Dim row As DataGridViewRow = GunaDataGridView2.Rows(e.RowIndex)
        'prodName = row.Cells(1).Value.ToString

        'If prodName = "" Then
        '    key = 0
        '    Stock = 0
        'Else
        '    key = Convert.ToInt32(row.Cells(0).Value.ToString)
        '    Stock = Convert.ToInt32(row.Cells(4).Value.ToString)
        '    Price = Convert.ToInt32(row.Cells(3).Value.ToString)
        'End If
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles lblTotal.Click

    End Sub


    Private Sub BtnRefresh_Click(sender As Object, e As EventArgs) Handles BtnRefresh.Click
        DisplayItem()
    End Sub
    Private Sub UpdateItem()
        Try
            Dim NewQnty = Stock - Convert.ToInt32(txtQuantity.Text)
            con.open()
            Dim query = "update Itemtb1 set ItQty='" & NewQnty & "' where ItId=" & key & ""
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            MsgBox("Item Updated")
            con.close()
            DisplayItem()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub blPrint_Click(sender As Object, e As EventArgs) Handles blPrint.Click
        AddBill()
        PrintPreviewDialog1.Show()
    End Sub

    Private Sub Label6_Click_1(sender As Object, e As EventArgs) Handles Label6.Click
        ViewOrder.Show()
        Me.Hide()
    End Sub
    Dim key = 0, Stock
    Private Sub ItemDGV_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles ItemDGV.CellMouseClick
        Dim row As DataGridViewRow = ItemDGV.Rows(e.RowIndex)
        prodName = row.Cells(1).Value.ToString

        If prodName = "" Then
            key = 0
            Stock = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
            Stock = Convert.ToInt32(row.Cells(4).Value.ToString)
            Price = Convert.ToInt32(row.Cells(3).Value.ToString)
        End If
    End Sub
    Private Sub AddBill()
        con.open()
        Dim query = "insert into Ordertb1 values('" & DateTime.Today.Date & "','" & GrandTotal & "')"
        Dim cmd As SqlCommand
        cmd = New SqlCommand(query, con)
        cmd.ExecuteNonQuery()
        MsgBox("Bill Added")
        con.close()

    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click
        Login.Show()
        Me.Hide()
    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        Login.Show()
        Me.Hide()
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawString("Cafe Shop", New Font("Arial", 22), Brushes.BlueViolet, 335, 35)
        e.Graphics.DrawString("****Your Bill****", New Font("Arial", 14), Brushes.BlueViolet, 350, 60)
        Dim imagebmp As New Bitmap(BillDGV.Width, BillDGV.Height)
        BillDGV.DrawToBitmap(imagebmp, New Rectangle(0, 0, BillDGV.Width, BillDGV.Height))
        e.Graphics.DrawImage(imagebmp, 250, 200)
        e.Graphics.DrawString("Total Amount  = " + GrandTotal.ToString(), New Font("Arial", 15), Brushes.Crimson, 325, 580)
        e.Graphics.DrawString("***************** Thanks for Visiting *******************", New Font("Arial", 15), Brushes.Crimson, 130, 600)

    End Sub

    Private Sub ComboBox1_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles CbItemCategory.SelectionChangeCommitted
        FilterByCategory()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles BtnAddtoBill.Click
        If key = 0 Then
            MsgBox("Select an item")

        ElseIf Convert.ToInt32(txtQuantity.Text) > Stock Then
            MsgBox("No Enough Stock")

        Else
            Dim rnum As Integer = BillDGV.Rows.Add()
            Dim total = Convert.ToInt32(txtQuantity.Text) * Price
            i = i + 1
            BillDGV.Rows.Item(rnum).Cells("Column1").Value = i
            BillDGV.Rows.Item(rnum).Cells("Column2").Value = prodName
            BillDGV.Rows.Item(rnum).Cells("Column3").Value = Price
            BillDGV.Rows.Item(rnum).Cells("Column4").Value = txtQuantity.Text
            BillDGV.Rows.Item(rnum).Cells("Column5").Value = total

            GrandTotal = GrandTotal + total
            lblTotal.Text = " Rs " + Convert.ToString(GrandTotal)
            UpdateItem()
            txtQuantity.Text = ""
            key = 0

        End If
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtQuantity.TextChanged

    End Sub
End Class